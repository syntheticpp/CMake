Namespace support for CMake:

   namespace(<string>)
   endnamespace()

It is possible to write code like this
(imagine antiX.cpp does not compile when the macro X is set):

namespace(x)
   add_definitions(-DX)
   add_library(X x.cpp)
endnamespace()
add_library(antiX antiX.cpp)


The CMake ticket is here
http://www.cmake.org/Bug/view.php?id=11793
